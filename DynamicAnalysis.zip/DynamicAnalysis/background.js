chrome.storage.onChanged.addListener(function(changes, namespace) {
  for (var key in changes) {
    var storageChange = changes[key];
    console.log('Storage change');
	console.log('Storage key "%s" in namespace "%s" changed. ' +
                'Old value was "%s", new value is "%s".',
                key,
                namespace,
                storageChange.oldValue,
                storageChange.newValue);
  }
});

chrome.bookmarks.onChanged.addListener(function(id, changeInfo) {
	console.log("Bookmark on change listener: Id value: "+ 
	"\n * id: " + id + 
	"\n * change object:  "+ JSON.stringify(changeInfo.bookmarks));
});

chrome.history.onVisited.addListener(function(result) {
	console.log("History visited: "+ JSON.stringify(result));
});

chrome.cookies.onChanged.addListener(function(changeInfo) {
  console.log('Cookie changed: ' +
              '\n * Cookie: ' + JSON.stringify(changeInfo.cookie) +
              '\n * Cause: ' + changeInfo.cause +
              '\n * Removed: ' + changeInfo.removed);
});

//This code is to check for page redirection

chrome.tabs.onUpdated.addListener(function listener(tabId, changedProps)
      {
    console.log(JSON.stringify(changedProps));
  }
);

//chrome.storage.local.set({"UserEnabledExtensions": "123"});

chrome.tabCapture.onStatusChanged.addListener(function(CaptureInfo){	
console.log("tab captured status change: "+ JSON.stringify(CaptureInfo));
});

chrome.system.cpu.getInfo(function(info){       
   console.log("CPU Details:: "+JSON.stringify(info));   
});

chrome.system.memory.getInfo(function(info){       
   //console.log("Memory Details:: "+JSON.stringify(info));
   console.log('Memory Details:: ' +
              '\n * JSON format: ' + JSON.stringify(info) +
              '\n * Total memory: ' + (info.capacity / 1073741824).toFixed(2) +  " GB\n" +
              '\n * used: ' + ((info.capacity - info.availableCapacity) / 1073741824).toFixed(2)+ " GB\n" +
			  '\n * used: ' + (info.availableCapacity / 1073741824).toFixed(2)+ " GB\n" ); 

		  
});

